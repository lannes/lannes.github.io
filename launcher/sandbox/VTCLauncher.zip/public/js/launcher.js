var VTC_LOGIN = 0;
var FACEBOOK_LOGIN = 1;
var GOOGLE_LOGIN = 2;

var gTypeLogin = VTC_LOGIN;
var gSocialToken = '';

var gIdPopup = '';

function openPopup(id) {
    gIdPopup = id;
    $('#' + id).reveal({
        animation: 'none',
        closeonbackgroundclick: false,
        escape: false
    });
}

function closePopup() {
    $('#' + gIdPopup).trigger('reveal:close');
    gIdPopup = '';
}

function showError(msg, callback) {
    closePopup();
	$('#pContent').html('<p>' + msg + '</p>');
    
    $("#btnClose").click(function() {
		closePopup();
		
		if (callback)
			callback();
	});
	
	openPopup('popupError');
}

function showWait() {
    $('#loader').reveal({
        animation: 'none',
        closeonbackgroundclick: false,
        escape: false
    });
}

function closeWait() {
    $('#loader').trigger('reveal:close');
}

function showRegister() {
	window.external.invoke(JSON.stringify({
		fn: 'register', 
		url: 'https://vtcgame.vn/Handler/register'
	}));
}


function showLogin() {
    $('#lblMessage').html('');
    openPopup('dangnhap');

	//$('#txtUsername').focus();
    $('#txtUsername').val(window.gUsername);
    $('#txtPassword').val('');
    if (window.gUsername !== '') {
        $('#chkRemember').prop('checked', true);
    }
}

function fromCpp(msg) {
	try {
		var json = JSON.parse(msg);
		
		if (json.fn == 'login') {
			callbackLogin(json.data);
			return;
		}
		
		if (json.fn == 'loginOTP') {
			callbackLoginOTP(json.data);
			return;
		}
	} catch (err) {
		alert(err);
	}
}

function callbackLogin(data) {
	closeWait();

	if (data == null) {
		openPopup('dangnhap');
		$('#lblMessage').html('Kết nối đến máy chủ không thành công. Xin vui lòng thử lại');
		return;
	}
	
	var error = data['error'];
	var message = data['message'];

	if (error == 200 || error == -1000) {
		$('#chkRemember').prop('checked', false);
		$('#lblUsername').html($('#txtUsername').val());
		$('#txtUsername').val('');
		$('#txtPassword').val('');

		if (error == -1000) {
			openPopup('popupOTP');
		}
	} else {
		openPopup('dangnhap');
		$('#lblMessage').html(message);
	}	
}

function login() {
    $('#lblMessage').html('');
    window.gUsername = $('#txtUsername').val();
    window.gPassword = $('#txtPassword').val();

    var remember = false;
    if ($('#chkRemember').is(':checked')) {
        remember = true;
    }

    closePopup();
    showWait();
	window.external.invoke(JSON.stringify({
		fn: 'login', 
		username: window.gUsername, 
		password: window.gPassword,
		remember: remember
	}));
}

function callbackLoginOTP(data) {
	$('#txtOTP').val('');

	closeWait();
	if (data == null) {
		openPopup('popupOTP');
		showError('<h3>Kết nối đến máy chủ không thành công. Xin vui lòng thử lại</h3><br><br><br>');
		return;
	}

	var error = data['error'];
	var message = data['message'];

	if (error == 200) {
		closePopup();
	} else {
		showError('<h3>' + message + '</h3><br><br><br>', function () {
			openPopup('popupOTP');
		});
	}	
}

function loginOTP() {
    var type = $('#cbTypeOTP').val();
    var otp = $('#txtOTP').val();

    closePopup();
    showWait();
	window.external.invoke(JSON.stringify({fn: 'loginOTP', type: type, otp: otp}));
}

function loginSDKSocial() {
    $('#lblSocialError').text('');
    if (gTypeLogin === FACEBOOK_LOGIN)
        loginSDKFacebook();
    if (gTypeLogin === GOOGLE_LOGIN)
        loginSDKGoogle();
}

function loginSDKFacebook() {
    LoginSDKFacebook($('#txtVTCusername').val(), gSocialToken).then(function (result) {
        try {
            var information = JSON.parse(result);
            var error = information['error'];
            var message = information['message'];

            if (error === 200) {
                $('#lblUsername').html($('#txtVTCusername').val());
                $('#txtVTCusername').val('');
                $('#mnuLogin').hide();
                $('#userInfo').show();
                closePopup();
            } else {
                $('#lblSocialError').text(message);
            }
        } catch (e) {
            console.log(e);
        }
    }, function (error) {
    });
}

function loginFacebook() {
    LoginFacebook().then(function (result) {
        return result;
    }).then(function (token) {
        gSocialToken = token;

        closePopup();
        showWait();
        LoginSDKFacebook('', token).then(function (result) {
            closeWait();

            var information = JSON.parse(result);
            var error = information['error'];

            if (error === 200) {
                $('#lblUsername').html(information['info']['accountName']);
                $('#txtVTCusername').val('');
                $('#mnuLogin').hide();
                $('#userInfo').show();
                closePopup();
            } else if (error === -500) {
                gTypeLogin = FACEBOOK_LOGIN;
                openPopup('username');
            } else if (error === -1000) {
                openPopup('popupOTP');
            } else {
                showError({
                    type: '',
                    msg: message + '<br><br><br></h3>'
                });
            }
        });
    }).catch(function (error) {

    });
}

function loginGoogle() {
    LoginGoogle().then(function (result) {
        return result;
    }).then(function (token) {
        gSocialToken = token;

        closePopup();
        showWait();
        LoginSDKGoogle('', token).then(function (result) {
            closeWait();

            var information = JSON.parse(result);
            var error = information['error'];

            if (error === 200) {
                $('#lblUsername').html(information['info']['accountName']);
                $('#txtVTCusername').val('');
                $('#mnuLogin').hide();
                $('#userInfo').show();
                closePopup();
            } else if (error === -500) {
                gTypeLogin = GOOGLE_LOGIN;
                openPopup('username');
            } else if (error === -1000) {
                openPopup('popupOTP');
            } else {
                showError({
                    type: '',
                    msg: message + '<br><br><br></h3>'
                });
            }
        });
    }).catch(function (error) {

    });
}

function loginSDKGoogle() {
    LoginSDKGoogle($('#txtVTCusername').val(), gSocialToken).then(function (result) {
        try {
            var information = JSON.parse(result);
            var error = information['error'];
            var message = information['message'];

            if (error === 200) {
                $('#lblUsername').html($('#txtVTCusername').val());
                $('#txtVTCusername').val('');
                $('#mnuLogin').hide();
                $('#userInfo').show();
                closePopup();
            } else {
                $('#lblSocialError').text(message);
            }
        } catch (e) {
            console.log(e);
        }
    }, function (error) {
    });
}

function OpenUrl(url) {
	window.external.invoke(JSON.stringify({
		fn: 'open_url', 
		url: url
	}));
}

function LoginFacebook() {
    return callCpp('{"name": "LoginFacebook"}');
}

function LoginSDKFacebook(username, token) {
    return callCpp('{"name": "LoginSDKFacebook", "username": "' + username + '", "token": "' + token + '"}');
}

function LoginGoogle() {
    return callCpp('{"name": "LoginGoogle"}');
}

function LoginSDKGoogle(username, token) {
    return callCpp('{"name": "LoginSDKGoogle", "username": "' + username + '", "token": "' + token + '"}');
}

$(function () {
    $('.cg_css_checkbox_popup_dangky').keydown(function (e) {
        if (e.which === 13) {
            var index = $('.cg_css_checkbox_popup_dangky').index(this) + 1;
            $('.cg_css_checkbox_popup_dangky').eq(index).focus();
            if (index === 2) {
                login();
            }
        }
    });
	
	showLogin();
});
